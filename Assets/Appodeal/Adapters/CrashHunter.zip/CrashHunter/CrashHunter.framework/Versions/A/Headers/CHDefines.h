//
//  CHDefines.h
//  CrashHunter
//
//  Created by Stas Kochkin on 14/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#ifndef CHDefines_h
#define CHDefines_h

#define CH_VERSION          @"1.15.12"


#endif /* CHDefines_h */
